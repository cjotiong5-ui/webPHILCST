<?php
// ══════════════════════════════════════════════════
//  includes/session_helper.php
//  ONE place that starts the session consistently.
//  Include this at the top of EVERY file that
//  needs sessions (auth.php, login.php, students.php,
//  attendance.php, etc.)
// ══════════════════════════════════════════════════

function philcst_session_start(): void {
    if (session_status() !== PHP_SESSION_NONE) return; // already started

    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
             || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
             || ((int)($_SERVER['SERVER_PORT'] ?? 80) === 443);

    session_set_cookie_params([
        'lifetime' => 86400,       // 24 hours
        'path'     => '/',
        'secure'   => $isHttps,    // true on InfinityFree (HTTPS)
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_name('PHILCST_SID');   // must be identical in every file
    session_start();
}