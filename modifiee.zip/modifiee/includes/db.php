<?php
// ══════════════════════════════════════════════════
//  includes/db.php — Database Connection
//  PhilCST Attendance System
//  Upload to: YOUR_SITE/includes/db.php
// ══════════════════════════════════════════════════

// ── InfinityFree Database Credentials ─────────────────────────────
define('DB_HOST',    'sql100.infinityfree.com');
define('DB_NAME',    'if0_41695273_philcst_attendance');
define('DB_USER',    'if0_41695273');
define('DB_PASS', 'Cj12345test');  // ← paste your InfinityFree DB password here
define('DB_CHARSET', 'utf8mb4');

// ── Admin Login Credentials ────────────────────────────────────────
// Username : admin
// Password : administrator
// These are FALLBACK credentials used when the DB admins table is unavailable.
// When the DB is connected, the admins table takes priority.
define('ADMIN_USERNAME',      'admin');
define('ADMIN_PASSWORD_HASH', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
// ↑ This is the bcrypt hash of 'administrator'

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error'   => 'Database connection failed: ' . $e->getMessage()
        ]);
        exit;
    }

    return $pdo;
}