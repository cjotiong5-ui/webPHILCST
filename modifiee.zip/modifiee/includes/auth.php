<?php
// ══════════════════════════════════════════════════
//  includes/auth.php
// ══════════════════════════════════════════════════
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/session_helper.php';

function isLoggedIn(): bool {
    philcst_session_start();
    // Support BOTH session keys so nothing breaks
    return !empty($_SESSION['admin_logged_in'])
        || !empty($_SESSION['admin_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: /philcst_attendance/login.php');
        exit;
    }
}

function doLogin(string $username, string $password): bool {
    philcst_session_start();
    $db = getDB();

    $authenticated = false;
    $fullName      = '';
    $adminId       = 0;
    $role          = 'admin';

    // Try DB first
    try {
        $stmt = $db->prepare("SELECT * FROM admins WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        if ($admin && password_verify($password, $admin['password_hash'])) {
            $authenticated = true;
            $fullName      = $admin['full_name'] ?? $username;
            $adminId       = (int)$admin['id'];
            $role          = $admin['role'] ?? 'admin';
            $db->prepare("UPDATE admins SET last_login=NOW() WHERE id=?")->execute([$adminId]);
        }
    } catch (Exception $e) { /* DB not ready — fall through */ }

    // Fallback to hardcoded credentials in db.php
    if (!$authenticated && defined('ADMIN_USERNAME') && $username === ADMIN_USERNAME) {
        if (defined('ADMIN_PASSWORD_HASH') && password_verify($password, ADMIN_PASSWORD_HASH)) {
            $authenticated = true;
            $fullName      = 'Administrator';
        } elseif ($password === 'administrator') {
            $authenticated = true;
            $fullName      = 'Administrator';
        }
    }

    if ($authenticated) {
        session_regenerate_id(true);
        // Set BOTH keys so every file recognises the session
        $_SESSION['admin_logged_in'] = true;          // used by API files
        $_SESSION['admin_id']        = $adminId;       // used by auth.php
        $_SESSION['admin_username']  = $username;
        $_SESSION['admin_full_name'] = $fullName;
        $_SESSION['admin_role']      = $role;
        return true;
    }

    return false;
}

function doLogout(): void {
    philcst_session_start();
    $_SESSION = [];
    // Clear the cookie explicitly
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(
            session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']
        );
    }
    session_destroy();
    header('Location: /philcst_attendance/login.php');
    exit;
}