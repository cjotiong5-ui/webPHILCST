<?php
/**
 * Role-Based Access Control (RBAC) for PhilCST Attendance
 */

// Define permission levels
define('ROLE_ADMIN', 'admin');       // Full access
define('ROLE_MANAGER', 'manager');   // Can manage attendance
define('ROLE_TEACHER', 'teacher');   // Can view own class
define('ROLE_VIEWER', 'viewer');     // Read-only access

// Permission matrix
$PERMISSIONS = [
    'admin' => [
        'view_all' => true,
        'export' => true,
        'delete_record' => true,
        'manage_users' => true,
        'view_reports' => true,
    ],
    'manager' => [
        'view_all' => true,
        'export' => true,
        'delete_record' => true,
        'manage_users' => false,
        'view_reports' => true,
    ],
    'teacher' => [
        'view_all' => false,        // Can only view their class
        'export' => true,
        'delete_record' => false,
        'manage_users' => false,
        'view_reports' => true,
    ],
    'viewer' => [
        'view_all' => true,
        'export' => false,          // Cannot export
        'delete_record' => false,
        'manage_users' => false,
        'view_reports' => false,    // Cannot see reports
    ],
];

/**
 * Check if user has a specific permission
 */
function hasPermission($permission) {
    global $PERMISSIONS;
    
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    $role = $_SESSION['admin_role'] ?? 'viewer';
    
    return $PERMISSIONS[$role][$permission] ?? false;
}

/**
 * Check if user has a specific role
 */
function hasRole($requiredRole) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    $userRole = $_SESSION['admin_role'] ?? 'viewer';
    
    $roleHierarchy = [
        'viewer' => 0,
        'teacher' => 1,
        'manager' => 2,
        'admin' => 3,
    ];
    
    return ($roleHierarchy[$userRole] ?? -1) >= ($roleHierarchy[$requiredRole] ?? 0);
}

/**
 * Require specific permission - redirect if denied
 */
function requirePermission($permission) {
    if (!hasPermission($permission)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'error' => 'Access Denied: Insufficient permissions']);
        exit;
    }
}

/**
 * Require specific role - redirect if denied
 */
function requireRole($role) {
    if (!hasRole($role)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'error' => "Access Denied: Requires {$role} role"]);
        exit;
    }
}

/**
 * Get user's role
 */
function getUserRole() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    return $_SESSION['admin_role'] ?? 'viewer';
}

/**
 * Get all permissions for user
 */
function getUserPermissions() {
    global $PERMISSIONS;
    return $PERMISSIONS[getUserRole()] ?? [];
}
